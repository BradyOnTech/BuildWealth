# Plan Context: Average Household Retirement Simulation

## Plan Summary

# Average Household Retirement Simulation

Alex and Jordan want to retire around age 65 while keeping enough cash for normal household surprises.

## What The User Wants To Test

- Whether current savings are enough.
- Whether to increase 401k, Roth IRA, HSA, or taxable contributions first.
- What happens if childcare costs last longer or income drops for a year.
- Which withdrawal order is easiest to understand and safest to explain.

## Task Snapshot

# Tasks

- [ ] Run the baseline retirement simulation.
- [ ] Compare maxing HSA before taxable brokerage.
- [ ] Compare a one-year income drop scenario.
- [ ] Ask Copilot to explain the difference in plain English.

## Plan Settings

- Annual contribution: default
- Horizon: default
- HSA extra contribution: default
- Marginal tax rate: default
- State tax rate: default
- Simulation mode: default
- Monte Carlo variant: default
- Historical start year: default
- Simulation seed: default
- Roth conversion annual target: default
- Roth conversion start age: default
- Roth conversion end age: default
- Household mode: individual
- Household partner income: default
- Household partner growth: default
- Household partner retirement age: default
- Household partner Social Security annual: default
- Household partner Social Security claiming age: default
- Household shared-goal target: default
- Household shared-goal target year: default
- Inflation rate: default
- Baseline return: default
- Optimistic return: default
- Conservative return: default
- Filing status: default
- Withdrawal strategy: not set
- Drawdown order: age_aware

## Standalone Modeling

- Timeline events: 0
- Contribution rules: 0
- Assumption sets: 5
- Active assumption set: default
- Branch templates: 7
- Default branch template: early_retirement

## Timeline Preview

- No timeline events configured.

## Recent Decisions

- [accepted] Updated plan timeline: 0 event(s). (2026-07-07T22:09:21.676666+00:00)
- [accepted] Updated plan timeline: 1 event(s). (2026-07-07T22:08:04.015491+00:00)
- [accepted] Updated plan timeline: 0 event(s). (2026-07-07T22:00:28.865215+00:00)
- [accepted] Updated plan timeline: 1 event(s). (2026-07-07T21:59:54.844087+00:00)
- [accepted] Updated plan timeline: 0 event(s). (2026-07-07T21:39:14.938275+00:00)
- [accepted] Updated plan timeline: 2 event(s). (2026-07-07T21:36:09.320690+00:00)
- [accepted] Seeded average-household demo plan. (2026-05-12T22:22:57.422170+00:00)
