# Tasks

- [ ] Run the baseline retirement simulation.
- [ ] Compare maxing HSA before taxable brokerage.
- [ ] Compare a one-year income drop scenario.
- [ ] Ask Copilot to explain the difference in plain English.
