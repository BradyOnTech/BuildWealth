# Average Household Retirement Simulation

Alex and Jordan want to retire around age 65 while keeping enough cash for normal household surprises.

## What The User Wants To Test

- Whether current savings are enough.
- Whether to increase 401k, Roth IRA, HSA, or taxable contributions first.
- What happens if childcare costs last longer or income drops for a year.
- Which withdrawal order is easiest to understand and safest to explain.
