# Tasks

- [ ] Run latest portfolio sync
- [ ] Ask Copilot for concentration-risk review
- [ ] Compare at least two contribution scenarios
