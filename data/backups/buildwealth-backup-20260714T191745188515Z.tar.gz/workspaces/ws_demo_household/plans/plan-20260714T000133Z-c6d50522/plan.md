# Alex Test plan

## Goal

- Define the primary financial outcome this plan is trying to achieve.

## Constraints

- Add constraints (tax, liquidity, risk, timeline).

## Strategy

- Document the high-level approach and tradeoffs.

## Questions For Copilot

- Add the next research questions to run through the agent workflow.
