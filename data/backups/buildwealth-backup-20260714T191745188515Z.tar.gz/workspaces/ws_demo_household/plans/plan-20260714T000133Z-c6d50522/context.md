# Plan Context: Alex Test plan

## Plan Summary

# Alex Test plan

## Goal

- Define the primary financial outcome this plan is trying to achieve.

## Constraints

- Add constraints (tax, liquidity, risk, timeline).

## Strategy

- Document the high-level approach and tradeoffs.

## Questions For Copilot

- Add the next research questions to run through the agent workflow.

## Task Snapshot

# Tasks

- [ ] Run latest portfolio sync
- [ ] Ask Copilot for concentration-risk review
- [ ] Compare at least two contribution scenarios

## Plan Settings

- Annual contribution: default
- Horizon: default
- HSA extra contribution: default
- Marginal tax rate: default
- State tax rate: default
- Simulation mode: default
- Monte Carlo variant: default
- Historical start year: default
- Simulation seed: default
- Roth conversion annual target: default
- Roth conversion start age: default
- Roth conversion end age: default
- Household mode: individual
- Household partner income: default
- Household partner growth: default
- Household partner retirement age: default
- Household partner Social Security annual: default
- Household partner Social Security claiming age: default
- Household shared-goal target: default
- Household shared-goal target year: default
- Inflation rate: default
- Baseline return: default
- Optimistic return: default
- Conservative return: default
- Filing status: default
- Withdrawal strategy: not set
- Drawdown order: age_aware

## Standalone Modeling

- Timeline events: 0
- Contribution rules: 0
- Assumption sets: 5
- Active assumption set: default
- Branch templates: 7
- Default branch template: early_retirement

## Timeline Preview

- No timeline events configured.

## Recent Decisions

- No decisions logged yet.
